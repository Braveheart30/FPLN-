@echo off
rem FPLN (beta) - opens FPLN in its own window. Updates arrive by themselves; nothing to re-download.
set "URL=https://braveheart30.github.io/FPLN-/"
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if exist "%EDGE%" (
  start "" "%EDGE%" --app="%URL%"
) else (
  start "" "%URL%"
)
