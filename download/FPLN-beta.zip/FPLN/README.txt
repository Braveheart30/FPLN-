FPLN · Flight Plan  ·  BETA 0.6.4 beta · 1 Nov 2026
==================================

START
  1. Double-click "Open FPLN.cmd". FPLN opens in its own window.
  2. Click "Install" on the banner at the bottom (or ... menu > Apps > Install this site as an app).
     FPLN gets its own taskbar icon and Start-menu entry, and works offline.
  3. Right-click the FPLN icon on the taskbar > Pin to taskbar.
  After that you never need this folder again. Open FPLN from the taskbar or Start menu.

UPDATES
  Automatic. Every time FPLN opens it loads the newest version, and if an update comes out
  while it's open you'll see "Update ready - Restart now". No downloads, ever.

WEB LINK
  https://braveheart30.github.io/FPLN-/   (works on phones too: open it, then "Add to Home Screen")

YOUR DATA
  Everything you enter stays on this computer, in Edge. Nothing is uploaded, and no one else can see it.
  Coming from the earlier FPLN.html test copy? Open the old copy > More > Backup > Copy backup,
  then in the new FPLN: More > Backup > paste > Restore.

FEEDBACK
  The speech-bubble button on Home. It goes straight to the FPLN team.

AI (Eric, "Load your plan")
  Needs a free Gemini key: More > Eric > paste a key from aistudio.google.com > Save.
  Keep CUI out of FPLN: no FRAGORDs, rosters or other cadets' personal information.
