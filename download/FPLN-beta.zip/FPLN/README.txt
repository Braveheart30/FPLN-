FPLN · Flight Plan  ·  BETA 1 (0.8.1)
==================================

INSTALL (about 1 minute)
  1. Double-click "Install FPLN.cmd". The FPLN page opens in Edge.
  2. Click the gold "Install FPLN" button, then "Install". FPLN opens in its own window.
  3. Follow the 2-minute pre-flight setup: your class, minute calls, alarm, sound test, theme.
  4. Right-click the FPLN icon on the taskbar > Pin to taskbar.
  After that you never need this folder again (keep the keep-awake files if you use the alarm overnight).

UPDATES
  Automatic. Every time FPLN opens it loads the newest version, and if an update comes out
  while it's open you'll see "Update ready - Restart now". No downloads, ever.

WEB LINK
  Double-click "FPLN (web link)" in this folder. On a phone, scan the QR code on the FPLN Share page,
  then "Add to Home Screen".

YOUR DATA
  Everything you enter stays on this computer, in Edge. Nothing is uploaded, and no one else can see it.
  Coming from the earlier FPLN.html test copy? Open the old copy > More > Backup > Copy backup,
  then in the new FPLN: More > Backup > paste > Restore.

ALARMS AND MINUTE CALLS OVERNIGHT
  FPLN keeps itself awake while it's open, even with the screen off. Run
  "FPLN keep awake.cmd" once so Windows doesn't sleep while plugged in
  ("FPLN undo keep awake.cmd" puts it back). For a backup that works even
  if the laptop sleeps, use Wake up > Back up alarms to my phone.

FEEDBACK
  The speech-bubble button on Home. It goes straight to the FPLN team.

AI (Eric, "Load your plan")
  Needs a free Gemini key: More > Eric > paste a key from aistudio.google.com > Save.
  Keep CUI out of FPLN: no FRAGORDs, rosters or other cadets' personal information.
