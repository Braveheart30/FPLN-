@echo off
title FPLN - undo keep awake
echo.
echo   This puts the plugged-in power settings back to common Windows defaults:
echo     - Screen off after 10 minutes
echo     - Sleep after 30 minutes
echo     - Closing the lid puts the laptop to sleep
echo.
choice /c YN /m "  Undo the FPLN keep-awake settings"
if errorlevel 2 goto cancel
set "FAIL="
powercfg /change monitor-timeout-ac 10 || set "FAIL=1"
powercfg /change standby-timeout-ac 30 || set "FAIL=1"
powercfg /setacvalueindex SCHEME_CURRENT SUB_BUTTONS LIDACTION 1 || set "FAIL=1"
powercfg /setactive SCHEME_CURRENT || set "FAIL=1"
echo.
if defined FAIL (echo   Some settings could not be changed; your IT policy may control them.) else (echo   Done. Your plugged-in settings are back to the defaults.)
echo.
pause
exit /b
:cancel
echo.
echo   Nothing was changed.
echo.
pause
